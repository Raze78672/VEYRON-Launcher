package git.artdeell.mojo.input.mouse;

import android.os.Build;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;

import androidx.annotation.RequiresApi;

import git.artdeell.mojo.Tools;

import git.artdeell.mojo.CallbackBridge;
import git.artdeell.mojo.game.platform.Platform;
import git.artdeell.mojo.prefs.LauncherPreferences;

@RequiresApi(api = Build.VERSION_CODES.O)
public class AndroidPointerCapture implements ViewTreeObserver.OnWindowFocusChangeListener, View.OnCapturedPointerListener, View.OnFocusChangeListener {
    private static final float TOUCHPAD_SCROLL_THRESHOLD = 1;
    private final View mTouchpadView;
    private final View mHostView;
    private final float mMousePrescale = Tools.dpToPx(1);
    private final PointerTracker mPointerTracker = new PointerTracker();
    private final Scroller mScroller = new Scroller(TOUCHPAD_SCROLL_THRESHOLD);
    private final float[] mVector = mPointerTracker.getMotionVector();

    private int mInputDeviceIdentifier;
    private boolean mDeviceSupportsRelativeAxis;

    public AndroidPointerCapture(View touchpad, View hostView) {
        this.mTouchpadView = touchpad;
        this.mHostView = hostView;
        hostView.setOnFocusChangeListener(this);
        hostView.setOnCapturedPointerListener(this);
        hostView.getViewTreeObserver().addOnWindowFocusChangeListener(this);
    }

    private void enableTouchpadIfNecessary() {
        if(mTouchpadView.getVisibility() != View.VISIBLE) mTouchpadView.setVisibility(View.VISIBLE);
    }

    public void handleAutomaticCapture() {
        if(mHostView.hasPointerCapture()) return;
        if(!mHostView.hasWindowFocus()) return;
        if(!mHostView.hasFocus()) {
            mHostView.requestFocus();
        } else {
            mHostView.requestPointerCapture();
        }
    }

    private void accumulateHistoricalValues(MotionEvent motionEvent, int axisX, int axisY) {
        float relX = motionEvent.getAxisValue(axisX),
                relY = motionEvent.getAxisValue(axisY);

        if(motionEvent.getHistorySize() > 1) for(int i = 0; i < motionEvent.getHistorySize(); i++) {
            relX += motionEvent.getHistoricalAxisValue(axisX, i);
            relY += motionEvent.getHistoricalAxisValue(axisY, i);
        }

        mVector[0] = relX;
        mVector[1] = relY;
    }

    @Override
    public boolean onCapturedPointer(View view, MotionEvent event) {
        checkSameDevice(event.getDevice());
        // Yes, we actually not only receive relative mouse events here, but also absolute touchpad ones!
        // Therefore, we need to know when it's a touchpad and when it's a mouse.

        if((event.getSource() & InputDevice.SOURCE_CLASS_TRACKBALL) != 0) {
            // If the source claims to be a relative device by belonging to the trackball class,
            // use its coordinates directly.
            if(mDeviceSupportsRelativeAxis) {
                // If some OEM decides to do a funny and make an absolute touchpad report itself as
                // a trackball, we will at least have semi-valid relative positions
                accumulateHistoricalValues(event, MotionEvent.AXIS_RELATIVE_X, MotionEvent.AXIS_RELATIVE_Y);
            }else {
                // Otherwise trust the OS, i guess??
                accumulateHistoricalValues(event, MotionEvent.AXIS_X, MotionEvent.AXIS_Y);
            }
        }else {
            // If it's not a trackball, it's likely a touchpad and needs tracking like a touchscreen.
            mPointerTracker.trackEvent(event);
            // The relative position will already be written down into the mVector variable.
        }

        // Avoid going through the JNI each time.
        if(!Platform.isGrabbing()) {
            enableTouchpadIfNecessary();
            // Yes, if the user's touchpad is multi-touch we will also receive events for that.
            // So, handle the scrolling gesture ourselves.
            mVector[0] *= mMousePrescale;
            mVector[1] *= mMousePrescale;
            if(event.getPointerCount() < 2) {
                applyMotionVector(LauncherPreferences.PREF_MOUSESPEED);
                mScroller.resetScrollOvershoot();
            } else {
                mScroller.performScroll(mVector);
            }
        } else {
            // Position is updated by many events, hence it is send regardless of the event value
            applyMotionVector(1);
        }

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                return true;
            case MotionEvent.ACTION_BUTTON_PRESS: CallbackBridge.sendMouseButton(event.getActionButton(), true); return true;
            case MotionEvent.ACTION_BUTTON_RELEASE: CallbackBridge.sendMouseButton(event.getActionButton(), false); return true;
            case MotionEvent.ACTION_SCROLL:
                CallbackBridge.sendScroll(
                        event.getAxisValue(MotionEvent.AXIS_HSCROLL),
                        event.getAxisValue(MotionEvent.AXIS_VSCROLL)
                );
                return true;
            case MotionEvent.ACTION_UP:
                mPointerTracker.cancelTracking();
                return true;
            default:
                return false;
        }
    }

    private void applyMotionVector(float speed) {
        Platform.cursorX += mVector[0] * speed;
        Platform.cursorY += mVector[1] * speed;
        Platform.sendCursorPosition();
    }

    private void checkSameDevice(InputDevice inputDevice) {
        int newIdentifier;
        if(inputDevice != null) newIdentifier = inputDevice.getId();
        else newIdentifier = Integer.MAX_VALUE;
        if(mInputDeviceIdentifier != newIdentifier) {
            reinitializeDeviceSpecificProperties(inputDevice);
            mInputDeviceIdentifier = newIdentifier;
        }
    }

    private void reinitializeDeviceSpecificProperties(InputDevice inputDevice) {
        mPointerTracker.cancelTracking();
        if(inputDevice == null) {
            mDeviceSupportsRelativeAxis = false;
            return;
        }
        boolean relativeXSupported = inputDevice.getMotionRange(MotionEvent.AXIS_RELATIVE_X) != null;
        boolean relativeYSupported = inputDevice.getMotionRange(MotionEvent.AXIS_RELATIVE_Y) != null;
        mDeviceSupportsRelativeAxis = relativeXSupported && relativeYSupported;
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        if(!hasWindowFocus) return;
        if(!mHostView.hasFocus()) mHostView.requestFocus();
        else mHostView.requestPointerCapture();
    }

    public void detach() {
        mHostView.setOnCapturedPointerListener(null);
        mHostView.getViewTreeObserver().removeOnWindowFocusChangeListener(this);
        mHostView.setOnFocusChangeListener(null);
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if(v != mHostView) return;
        if(hasFocus && mHostView.hasWindowFocus()) mHostView.requestPointerCapture();
        if(!hasFocus) mHostView.releasePointerCapture();
    }
}
